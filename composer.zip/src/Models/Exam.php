<?php

namespace CM\Models;
use CM\Libs\Abstracts\Models;

class Exam extends Models{
    
}