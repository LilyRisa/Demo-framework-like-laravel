<?php

namespace CM\Models;
use CM\Libs\Abstracts\Models;

class Users extends Models{
    
}