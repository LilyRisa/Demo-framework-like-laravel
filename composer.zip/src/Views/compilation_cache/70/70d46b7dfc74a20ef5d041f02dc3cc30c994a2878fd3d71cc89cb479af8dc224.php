<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html */
class __TwigTemplate_3aaf4a3a923872b7eec510d5a13309412c984584608bd8adba0d1936f3a0fba2 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'script' => [$this, 'block_script'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html", "index.html", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "
    

    <div class=\"container\">
        <div class=\"panel panel-warning\">
            <div class=\"panel-heading\"><h2>Thống kê</h2></div>
        <div class=\"panel-body\">
            <table class=\"table\">
                <thead>
                  <tr>
                    <th scope=\"col\">ID</th>
                    <th scope=\"col\">Name</th>
                    <th scope=\"col\">Birthday</th>
                    <th scope=\"col\">DEV</th>
                    <th scope=\"col\">Tổng điểm</th>
                  </tr>
                </thead>
                <tbody>
                    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["users"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 23
            echo "                        <tr>
                            <th scope=\"row\">";
            // line 24
            echo twig_escape_filter($this->env, (($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = $context["user"]) && is_array($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4) || $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 instanceof ArrayAccess ? ($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4["id"] ?? null) : null), "html", null, true);
            echo "</th>
                            <td>";
            // line 25
            echo twig_escape_filter($this->env, (($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = $context["user"]) && is_array($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144) || $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 instanceof ArrayAccess ? ($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144["name"] ?? null) : null), "html", null, true);
            echo "</td>
                            <td class=\"birthday\">";
            // line 26
            echo twig_escape_filter($this->env, (($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b = $context["user"]) && is_array($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b) || $__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b instanceof ArrayAccess ? ($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b["birthday"] ?? null) : null), "html", null, true);
            echo "</td>
                            <td>";
            // line 27
            echo twig_escape_filter($this->env, (($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = $context["user"]) && is_array($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002) || $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 instanceof ArrayAccess ? ($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002["dev"] ?? null) : null), "html", null, true);
            echo "</td>
                            <td>";
            // line 28
            echo twig_escape_filter($this->env, (($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 = $context["user"]) && is_array($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4) || $__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 instanceof ArrayAccess ? ($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4["point"] ?? null) : null), "html", null, true);
            echo "</td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        echo "                 
                </tbody>
              </table>
        </div>
        </div>
    </div>
    <div class=\"container\">
        <div class=\"panel panel-warning\">
            <div class=\"panel-heading\"><h2>Load json to server</h2></div>
        <div class=\"panel-body\">
            <div class=\"fom-group\">
                <div class=\"row\">
                    <div class=\"col-md-3\">
                        <label for=\"dev\">Dev</label>
                        <input type=\"text\" class=\"form-control\" id=\"dev\" value=\"Dev2\">
                    </div>
                    <div class=\"col-md-3\">
                        <label for=\"date\">Date exam</label>
                        <input type=\"text\" class=\"form-control\" id=\"date\" value=\"9/10/2019\">
                    </div>
                    <div class=\"col-md-3\">
                        <button class=\"btn btn-success\"  id=\"load\">Load</button>
                    </div>
                    <div class=\"col-md-3\">
                        <a href=\"index.php?route=bonus\">Thưởng nhân viên</a>
                    </div>
                </div>
            </div>
            <table class=\"table\">
                <thead>
                  <tr>
                    <th scope=\"col\">ID</th>
                    <th scope=\"col\">Name</th>
                    <th scope=\"col\">Birthday</th>
                    <th scope=\"col\">DEV</th>
                    <th scope=\"col\">Tổng điểm</th>
                  </tr>
                </thead>
                <tbody id=\"body_load\">
                    
                 
                </tbody>
              </table>
        </div>
        </div>
    </div>
";
    }

    // line 78
    public function block_script($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 79
        echo "<script>
    \$(document).ready(function(){
        let date = \$('.birthday')
        for(let i=0; i<date.length;i++){
            if(moment(\$(date).eq(i).text(), 'MM/DD/YYYY',true).isValid()){
                \$(date).eq(i).html(\$(date).eq(i).text()+' <p style=\"color:blue\">Đúng định dạng mm/dd/yyyy</p>')
            }else{
                \$(date).eq(i).html(\$(date).eq(i).text()+' <p style=\"color:red\">Sai định dạng mm/dd/yyyy</p>')
            }
        }

        \$('#load').on('click', function(e){
            e.preventDefault()
            let dev = \$('#dev').val() == '' ? 'dev' : \$('#dev').val()
            let date_exam = \$('#date').val() == '' ? 'date_exam' : \$('#date').val()
            \$.ajax({
                url: 'index.php?route=search',
                type: 'POST',
                data: {
                    dev: dev,
                    date_exam : date_exam
                }
            }).done(resp => {

                if(resp == []){
                    alert('Không có dữ liệu')
                }else{
                    \$.each(resp, function(index,item){
                        let tmp = `
                        <tr>
                            <th scope=\"row\">\${item.id}</th>
                            <td>\${item.name}</td>
                            <td class=\"birthday\">\${item.birthday} 
                                \${moment(item.birthday, 'MM/DD/YYYY',true).isValid() ? '<p style=\"color:blue\">Đúng định dạng mm/dd/yyyy</p>': '<p style=\"color:red\">Sai định dạng mm/dd/yyyy</p>'}
                                </td>
                            <td>\${item.dev}</td>
                            <td>\${item.point}</td>
                        </tr>`;
                        \$('#body_load').append(tmp);
                    })
                }

            }).fail(e => {

            })
        })
        

    })
</script>
";
    }

    public function getTemplateName()
    {
        return "index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  157 => 79,  153 => 78,  103 => 31,  94 => 28,  90 => 27,  86 => 26,  82 => 25,  78 => 24,  75 => 23,  71 => 22,  51 => 4,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "index.html", "C:\\Users\\minhm\\Desktop\\Luvina\\src\\Views\\index.html");
    }
}
