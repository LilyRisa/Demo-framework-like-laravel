<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layout.html */
class __TwigTemplate_4566c374d4254339009e85d3247a86c5a2b7c4b955cc818b05fc06b3d8e6be28 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'content' => [$this, 'block_content'],
            'script' => [$this, 'block_script'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
";
        // line 4
        $this->loadTemplate("layout/head.html", "layout.html", 4)->display($context);
        // line 5
        $this->displayBlock('head', $context, $blocks);
        // line 6
        echo "</head>
<body>
    
    ";
        // line 9
        $this->displayBlock('content', $context, $blocks);
        // line 10
        echo "
    ";
        // line 11
        $this->loadTemplate("layout/footer.html", "layout.html", 11)->display($context);
        // line 12
        echo "    ";
        $this->displayBlock('script', $context, $blocks);
        // line 13
        echo "</body>
</html>";
    }

    // line 5
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 9
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 12
    public function block_script($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "layout.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 12,  75 => 9,  69 => 5,  64 => 13,  61 => 12,  59 => 11,  56 => 10,  54 => 9,  49 => 6,  47 => 5,  45 => 4,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "layout.html", "C:\\Users\\minhm\\Desktop\\Luvina\\src\\Views\\layout.html");
    }
}
