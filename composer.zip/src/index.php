<?php
require __DIR__ . '/../vendor/autoload.php';
require __DIR__ .'/../global.php';
require __DIR__ .'/../conf.php';
require 'Routes/Web.php';
